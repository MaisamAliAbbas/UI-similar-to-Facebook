package com.zasa.topcars;

public class ModelClass {
    private int image_view;

    public ModelClass(int image_view) {
        this.image_view = image_view;
    }

    public ModelClass() {

    }

    public int getImage_view() {
        return image_view;
    }

    public void setImage_view(int image_view) {
        this.image_view = image_view;
    }
}
