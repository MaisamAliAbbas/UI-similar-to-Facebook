package com.zasa.topcars;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zasa.topcars.databinding.RvRowsBinding;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    ArrayList<ModelClass>itemlist;
    Context context;

    public Adapter(ArrayList<ModelClass> itemlist, Context context) {
        this.itemlist = itemlist;
        this.context = context;
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RvRowsBinding binding=RvRowsBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        ModelClass modelClass=itemlist.get(position);
        holder.binding.ivRvImage.setImageResource(modelClass.getImage_view());
    }

    @Override
    public int getItemCount() {
        return itemlist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RvRowsBinding binding;
        public ViewHolder(RvRowsBinding binding) {
            super(binding.getRoot());
            binding=binding;
        }
    }
}
